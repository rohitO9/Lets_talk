// ignore_for_file: file_names

import 'package:astrowaypartner/utils/CallUtils.dart';

class CallHandler {
  void handleIncomingCall(var messagedata) {
    CallUtils.showIncomingCall(messagedata);
  }
}
