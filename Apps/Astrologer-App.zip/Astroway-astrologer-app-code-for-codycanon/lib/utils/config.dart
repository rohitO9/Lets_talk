// ignore_for_file: non_constant_identifier_names, dangling_library_doc_comments

///  =================================================================
/// ********************** BASE URL FOR API ********************
/// ==================================================================
///
String contactsupportEmail = "support@gmail.com";
String imgBaseurl = "https://astroway.diploy.in/";
String pdfBaseurl = "https://astroway.diploy.in/public";
String appMode = "LIVE";
String OtplessappId = "EGN337D0735VTPMTMAYA";

String storiesIcon = "assets/images/stories_icon.png";

Map<String, dynamic> appParameters = {
  "LIVE": {
    "apiUrl": "https://astroway.diploy.in/api/",
  },
  "DEV": {
    "apiUrl": "https://astroway.diploy.in/api/",
  }
};
