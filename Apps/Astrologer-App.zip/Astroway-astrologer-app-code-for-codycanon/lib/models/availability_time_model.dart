class AvailabilityTimeModel {
  int? id;
  String? availableTime;
  String? name;
  AvailabilityTimeModel({this.id, this.availableTime, this.name});
}
