// ignore_for_file: file_names

class IMAGECONST {
  static const String getxImage = "assets/images/getxImage.jpg";
  static const String splashImage = "assets/images/splash.png";
  static const String verificationImage = "assets/images/please_varification.png";
  static const String arrowLeft = "assets/images/arrow_left.png";
  static const String thankYouImage = "assets/images/thank_you_image.png";
  static const String sky = "assets/images/sky.jpg";
  static const String whatsapp = "assets/images/whatsapp.png";
  static const String aquarius = "assets/images/aquarius.png";
  static const String male = "assets/images/maleGender.png";
  static const String female = "assets/images/femaleGender.png";
  static const String otherGender = "assets/images/otherGender.png";
  static const String astroChart = "assets/images/astro-chart.jpg";
  static const String southAstroChart = "assets/images/south-astro-chart.jpg";
  static const String wallet = "assets/images/wallet.png";
}
