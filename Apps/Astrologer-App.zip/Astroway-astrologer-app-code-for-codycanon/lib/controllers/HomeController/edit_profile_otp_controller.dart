import 'package:get/get.dart';

class EditProfileOTPController extends GetxController {
  String screen = 'edit_profile_otp_controller.dart';
  double second = 0;
  var maxSecond = 60;
}
